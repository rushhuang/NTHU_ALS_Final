/*******************************************************************************
+
+  LEDA 5.2  
+
+
+  geo_alg.h
+
+
+  Copyright (c) 1995-2007
+  by Algorithmic Solutions Software GmbH
+  All rights reserved.
+ 
*******************************************************************************/

// $Revision: 1.2 $  $Date: 2007/02/25 00:48:21 $

#include <LEDA/geo/rat_geo_alg.h>
#include <LEDA/geo/real_geo_alg.h>
#include <LEDA/geo/float_geo_alg.h>

#include <LEDA/geo/truncate.h>

