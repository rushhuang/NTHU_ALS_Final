#define LEDA_STD_INCLUDE
#include_next <values.h>
#undef LEDA_STD_INCLUDE

